#############################
README.txt
James Watson, 2018 September
Building, Running, and Usage directions for Homework submission
#############################

=== Build Instructions ===

In the root directory for the project:
make

___ End Build ___


=== Run Instructions ===

In the root directory for the project:
./HW2

___ End Run ___


=== Usage Instructions ===

~~ Keys ~~
[Arrow Up/Dn] : Pitch the plot on a horizontal axis parallel to the screen
[Arrow Rt/Lf] : Yaw the plot about its own Y axis
[s] : _________ Activate sigma edit mode
[r] : _________ Activate rho   edit mode
[b] : _________ Activate beta  edit mode
[+/-] : _______ Increment / Decrement the parameter indicated by the edit mode
[n] : _________ Deactivate parameter editing , [+/-] have no effect , Program starts in this mode
[Esc/0] : _____ Close program

___ End Usage ___
